<template>
  <div class="header">
    <div class="header-left">
      <span class="iconfont">&#xe624;</span>
    </div>
    <div class="header-input"><span class="iconfont">&#xe632;</span>输入城市/景点</div>
    <div class="header-right">{{this.city}}<span class="iconfont">&#xe64a;</span></div>
  </div>
</template>

<script>
export default{
  name: 'HomeHeader',
  props: {
    city: String
  }
}
</script>

<!--scoped限制只对header有效
1rem = html font-size=50px (重置样式中已经设置了)-->
<style rel="stylesheet/stylus" lang="stylus" scoped>
  /*@import "../../../assets/styles/varibles.styl"*/
  @import "~@/assets/styles/varibles.styl"
  /*@import "~sty/varibles.styl"*/
  .header
    display: flex
    height: .86rem
    line-height .86rem
    background: $bgColor
    color: #ffffff
    .header-left
      width: .64rem
      float: left
      text-align center
      font-size .4rem
    .header-input
      flex: 1
      height .64rem
      line-height .64rem
      margin-left .2rem
      margin-top .12rem
      padding-left .2rem
      background: #ffffff
      border-radius .1rem
      color #ccc
    .header-right
      width: 1.24rem
      float: right
      text-align: center
      span
        font-size .24rem
</style>
