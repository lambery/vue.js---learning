<template>
  <div class="header">
    <div class="header-left">
      <span class="iconfont">&#xe624;</span>
    </div>
    <div class="header-input"><span class="iconfont">&#xe632;</span>输入城市/景点</div>
    <router-link to="/city">
      <div class="header-right">{{this.city}}<span class="iconfont">&#xe64a;</span></div>
    </router-link>
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default{
  name: 'HomeHeader',
  computed: {
    ...mapState(['city'])
  }
}
</script>

<!--scoped限制只对header有效
1rem = html font-size=50px (重置样式中已经设置了)-->
<style rel="stylesheet/stylus" lang="stylus" scoped>
  /*@import "../../../assets/styles/varibles.styl"*/
  @import "~@/assets/styles/varibles.styl"
  /*@import "~sty/varibles.styl"*/
  .header
    display: flex
    height: $headerHeight
    line-height $headerHeight
    background: $bgColor
    color: #ffffff
    .header-left
      width: .64rem
      float: left
      text-align center
      font-size .4rem
    .header-input
      flex: 1
      height .64rem
      line-height .64rem
      margin-left .2rem
      margin-top .12rem
      padding-left .2rem
      background: #ffffff
      border-radius .1rem
      color #ccc
    .header-right
      padding 0 .1rem
      min-width: 1.04rem
      float: right
      text-align: center
      color #ffffff
      span
        font-size .24rem
</style>
