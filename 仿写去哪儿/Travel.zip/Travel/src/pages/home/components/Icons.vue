<template>
  <div class="icons">
    <swiper :options="swiperOption">
      <swiper-slide v-for="(page, index) of pages" :key="index">
        <div class="icon" v-for="item of page" :key="item.id">
          <div class="icon-img">
            <img class="icon-img-content" :src="item.imgUrl" alt="">
          </div>
          <p class="icon-des">{{item.desc}}</p>
        </div>
      </swiper-slide>
    </swiper>
  </div>

</template>

<script>
export default{
  props: {
    list: Array
  },
  name: 'HomeIcons',
  data: function () {
    return {
      swiperOption: {
        autoplay: false
      }
    }
  },
  computed: {
    pages: function () {
      const pages = []
      this.list.forEach(function (item, index) {
        const page = Math.floor(index / 8)
        if (!pages[page]) {
          pages[page] = []
        }
        pages[page].push(item)
      })
      return pages
    }
  }
}
</script>

<style rel="stylesheet/stylus" lang="stylus" scoped>
  @import "~sty/varibles.styl"
  @import "~sty/mixins.styl"
  .icons >>> .swiper-container
    //overflow hidden
    height 0
    padding-bottom 50%
    //background: green
  .icon
    overflow hidden
    float left
    width: 25%
    height 0
    padding-bottom 25%
    //background: red
    position relative
    .icon-img
      position absolute
      top 0
      left 0
      right 0
      bottom .44rem
      box-sizing border-box
      padding .1rem
      //background: blue
      .icon-img-content
        display block
        margin 0 auto
        height 100%
    .icon-des
      position absolute
      left 0
      right 0
      bottom 0
      height .44rem
      line-height .44rem
      text-align center
      color $darkTextColor
      ellipsis()
      /*overflow hidden
      /*white-space: nowrap
      /*text-overflow ellipsis*/
</style>
