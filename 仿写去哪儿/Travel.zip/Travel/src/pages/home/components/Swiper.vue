<template>
  <div class="wrapper">
  <swiper :options="swiperOption" v-if="showSwiper">
    <!-- slides -->
    <swiper-slide v-for="item of list" :key="item.id">
      <img class="swiper-img" :src="item.imgUrl" alt="">
    </swiper-slide>
    <!--<swiper-slide><img class="swiper-img" src="http://img1.qunarzz.com/piao/fusion/1810/eb/5cacf42b59e91e02.jpg_750x200_9c0a77b0.jpg" alt=""></swiper-slide>-->
    <!--<swiper-slide><img class="swiper-img" src="http://img1.qunarzz.com/piao/fusion/1809/47/7599053a2cb2ee02.jpg_750x200_c61be0c1.jpg" alt=""></swiper-slide>-->

    <!-- Optional controls -->
    <div class="swiper-pagination"  slot="pagination"></div>
  </swiper>
  </div>
</template>

<script>
export default{
  props: {
    list: Array
  },
  name: 'HomeSwiper',
  data () {
    return {
      swiperOption: {
        pagination: '.swiper-pagination',
        loop: true,
        autoplay: 2000,
        autoplayStopOnLast: true
      }
    }
  },
  computed: {
    showSwiper () {
      return this.list.length
    }
  }
}
</script>

<!--padding-bottom 31.25%相对宽度撑开高
.wrapper >>> .swiper-pagination-bullet-active穿透不受scoped限制-->
<style rel="stylesheet/stylus" lang="stylus" scoped>
  .wrapper >>> .swiper-pagination-bullet-active
    background: #fff
  .wrapper
    width 100%
    height 0
    padding-bottom 31.25%
    overflow hidden
    .swiper-img
      width 100%
</style>
