<template>
  <div>
    <div class="title">周末去哪儿玩</div>
    <ul>
      <li class="item border-bottom" v-for="item of list" :key="item.id">
        <div class="item-img-content">
          <img class="item-img" :src="item.imgUrl" alt="">
        </div>
        <div class="item-info">
          <p class="item-title">{{item.title}}</p>
          <p class="item-desc">{{item.desc}}</p>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: {
    list: Array
  },
  name: 'HomeWeekend',
  data: function () {
    return {

    }
  }
}
</script>

<style rel="stylesheet/stylus" lang="stylus" scoped>
  @import "~sty/mixins.styl"
  .title
    line-height .8rem
    background: #eee
    text-indent .2rem
  .item-img-content
    overflow hidden
    height 0
    padding-bottom 37.44%
    .item-img
      width 100%
  .item-info
    padding .14rem .2rem .2rem .2rem
    margin-bottom .1rem
    .item-title
      line-height .48rem
      font-size .28rem
      padding-right: 1.4rem
      ellipsis()
    .item-desc
      line-height .42rem
      font-size .24rem
      padding-right: 1.4rem
      color #616161
      ellipsis()
</style>
