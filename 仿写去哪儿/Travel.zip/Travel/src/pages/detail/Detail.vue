<template>
<div>
  <detail-banner></detail-banner>
</div>
</template>

<script>
import DetailBanner from './components/banner.vue'
export default{
  name: 'Detail',
  components: {
    DetailBanner
  }
}
</script>

<style rel="stylesheet/stylus" lang="stylus" scoped>

</style>
