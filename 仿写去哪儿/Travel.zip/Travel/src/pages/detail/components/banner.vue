<template>
  <div>
    <div class="banner" @click="handleBannerClick">
      <img class="banner-img" src="http://img1.qunarzz.com/sight/p0/1810/2d/2d7b45e94187416ea3.img.jpg_600x330_26145653.jpg" alt="">
      <div class="banner-info">
        <div class="banner-title">长隆野生动物世界(AAAAA景区)</div>
        <div class="banner-number"><span class="iconfont banner-icon">&#xe67b;</span>39</div>
      </div>
    </div>
    <common-gallary :imgs="imgs" v-show="showGallary" @close="hidePic"></common-gallary>
  </div>
</template>

<script>
import CommonGallary from 'common/gallary/Gallary'
export default{
  name: 'DetailBanner',
  data: function () {
    return {
      showGallary: false,
      imgs: ['http://img1.qunarzz.com/sight/p0/1605/d4/d4e2dce9d328d5b290.img.jpg_r_800x800_892973df.jpg', 'http://img1.qunarzz.com/sight/p0/1605/86/86844ca30265d1d190.img.jpg_r_800x800_c2f09148.jpg']
    }
  },
  methods: {
    handleBannerClick () {
      this.showGallary = true
    },
    hidePic: function () {
      this.showGallary = false
    }
  },
  components: {
    CommonGallary
  }
}
</script>

<style rel="stylesheet/stylus" lang="stylus" scoped>
  .banner
    position relative
    overflow hidden
    height 0
    padding-bottom 55%
    .banner-img
      width: 100%
    .banner-info
      display flex
      position absolute
      right 0
      left 0
      bottom 0
      line-height .6rem
      color #ffffff
      background-image: linear-gradient(top, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.8));
      .banner-title
        flex 1
        font-size .32rem
        padding 0 .2rem
      .banner-number
        margin-top .14rem
        padding 0 .4rem
        line-height .32rem
        height .32rem
        border-radius .2rem
        background rgba(0, 0, 0, .8)
        font-size .24rem
        .banner-icon
          font-size .24rem
</style>
