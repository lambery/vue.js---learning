<template>
  <div class="list" ref="wrapper">
    <div>
      <div class="area">
        <div class="title border-topbottom">当前城市</div>
        <div class="button-list">
          <div class="button-wrapper">
            <div class="button">{{this.$store.state.city}}</div>
          </div>
        </div>
      </div>
      <div class="area">
        <div class="title border-topbottom">热门城市</div>
        <div class="button-list">
          <div class="button-wrapper"  v-for="item of hotCities" :key="item.id" @click="handleCityClick(item.name)">
            <div class="button">{{item.name}}</div>
          </div>
        </div>
      </div>
      <div class="area" v-for="(item, key) of cities" :key="key" :ref="key">
        <div class="title border-topbottom">{{key}}</div>
        <div class="item-list">
          <div class="item border-bottom" v-for="item2 of item" :key="item2.id" @click="handleCityClick(item2.name)">{{item2.name}}</div>
        </div>
      </div>
    </div>
    <div class="UpTop" @click="handleUP" v-if="show">^</div>
  </div>
</template>

<script>
import Bscroll from 'better-scroll'
export default {
  props: {
    cities: Object,
    hotCities: Array,
    letter: String
  },
  data: function () {
    return {
      show: false
    }
  },
  name: 'CityList',
  mounted: function () {
    this.scroll = new Bscroll(this.$refs.wrapper)
    var that = this
    this.scroll.on('scrollEnd', function () {
      if (Math.abs(parseInt(that.scroll.y)) !== 0) {
        that.show = true
      } else {
        that.show = false
      }
    })
  },
  watch: {
    letter () {
      if (this.letter) {
        const element = this.$refs[this.letter][0]
        this.scroll.scrollToElement(element, 500)
      }
    }
  },
  methods: {
    handleUP: function () {
      this.scroll.scrollTo(0, 0, 500)
      this.show = false
    },
    handleCityClick: function (city) {
      this.$store.dispatch('changeCity', city)
      this.$router.push('/')
    }
  }
}
</script>

<style rel="stylesheet/stylus" lang="stylus" scoped>
  @import "~sty/varibles.styl"
  .border-topbottom
    &:before
      border-color #ccc
    &:after
      border-color #ccc

  .border-bottom
    &:before
      border-color #ccc

  .list
    overflow hidden
    position absolute
    top 1.58rem
    left 0
    right 0
    bottom 0
    .title
      line-height .54rem
      background: #eee
      padding-left .2rem
      color #666
      font-size .26rem
    .button-list
      overflow hidden
      padding .1rem .6rem .1rem .1rem
      .button-wrapper
        float left
        width 33.33%
        .button
          padding .1rem 0
          text-align center
          margin .1rem
          border .02rem solid #cccccc
          border-radius 8%
    .item-list
      .item
        line-height .76rem
        padding-left .2rem

  .UpTop
    position fixed
    right 1.2rem
    bottom 1.2rem
    background: $bgColor
    color #cccccc
    font-size 1rem
    height .2rem
    line-height .2rem
    border-radius 50%
</style>
