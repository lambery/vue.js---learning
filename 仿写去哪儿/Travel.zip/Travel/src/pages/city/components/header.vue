<template>
  <div class="header">
    城市选择
    <router-link to="/">
      <div><span class="iconfont header-back">&#xe624;</span></div>
    </router-link>
  </div>
</template>

<script>
export default {
  name: 'CityHeader'
}
</script>

<style  rel="stylesheet/stylus" lang="stylus" scoped>
  @import "~sty/varibles.styl"
  .header
    position relative
    height $headerHeight
    line-height $headerHeight
    text-align center
    overflow hidden
    color #ffffff
    background: $bgColor
    font-size .32rem
  .header-back
    width .64rem
    top 0
    left 0
    text-align center
    font-size .4rem
    position absolute
    color #ffffff
</style>
